/******************************************************************************
* Licensed Materials - Property of IBM
*
* (C) Copyright IBM Corp. 2012 All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*
*****************************************************************************/
package com.ibm.ap;

import java.util.ArrayList;
import java.util.List;

import com.ibm.itim.ws.client.util.xml.XMLBeanReader;
import com.ibm.itim.ws.client.util.xml.XMLBeanWriter;
import com.ibm.itim.ws.model.WSSession;
import com.ibm.itim.ws.services.WSExtensionService;
import com.ibm.itim.ws.services.WSInvalidLoginException;
import com.ibm.itim.ws.services.WSLoginServiceException;
import com.ibm.itim.ws.services.WSSessionService;


public class IAMApprovalService extends GenericWSClient {

	public static void main(String[] args) {		
		
		IAMApprovalService client=new IAMApprovalService();
		try {
			List<String> inputlist=new ArrayList<String>();
			inputlist.add(args[0]);
			inputlist.add(args[1]);
			inputlist.add(args[2]);
			inputlist.add(args[3]);
			inputlist.add(args[4]);
			
			client.doAction(inputlist);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

	
	public String doAction(List<String> inputList)throws Exception {				
		        if(inputList.size()<=2 ) {
		        	return "Please provide the required parameters.";
		        }
				String principal="xxx";
				String credential="xxx";
				System.out.println("performing login..."+inputList.size());
				
				WSSession session = loginIntoITIM(principal, credential);
				// Convert the object to XML string
				
				System.out.println("calling extension service...");
				String inputXML = XMLBeanWriter.writeXMLBean(inputList);
				
				WSExtensionService extensionService = getExtensionService();
				// Execute the sample logic to get the service group names of
				// the services which 'John Smith' owns
				String resultStr = extensionService.extendWithXML(session,
						"com.ibm.extension.iam.IAMApprovalHandler",
						"performAction", inputXML);
				
				String result = (String) XMLBeanReader.readXMLBean(resultStr, String.class);				
					
				System.out.println("approval handling closed Sucessfully.."+result);
				
				return "Action performed successfully";
	}
	
	private WSSession loginIntoITIM(String principal, String credential)
				throws WSInvalidLoginException, WSLoginServiceException {
			WSSessionService proxy = getSessionService();
			WSSession session = proxy.login(principal, credential);
			if (session != null) {
		
			} else {
			}
			return session;
	}
	
}
