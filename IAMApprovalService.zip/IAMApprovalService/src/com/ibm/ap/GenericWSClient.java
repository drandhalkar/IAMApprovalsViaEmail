/******************************************************************************
* Licensed Materials - Property of IBM
*
* (C) Copyright IBM Corp. 2005, 2012 All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*
*****************************************************************************/
package com.ibm.ap;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;

import com.ibm.itim.ws.services.WSExtensionService;
import com.ibm.itim.ws.services.WSExtensionServiceService;
import com.ibm.itim.ws.services.WSSessionService;
import com.ibm.itim.ws.services.WSSessionService_Service;
import com.ibm.itim.ws.services.WSToDoService;
import com.ibm.itim.ws.services.WSToDoServiceService;

public abstract class GenericWSClient {

	// Command line argument names prefixed by "-"
	
	static String IAM_WEBSERVICE_HOST = "xxxxx";
	static String IAM_WEBSERVICE_PORT = "xxxx";
	
	static final String WS_SUFFIX = "/itim/services/";
	static final String WS_WSDL_LOCATION = "/WEB-INF/wsdl/";
	static final String namespaceURI = "http://services.ws.itim.ibm.com";
	
	static boolean isCustomHostAndPortProvided = true;
	
	/*
	 * The static block below reads the duwsconfig.properties file 
	 * and sets the values of HOST and PORT */
	static {		
		
		System.out.println("Using resourse bundle Hostname:"+IAM_WEBSERVICE_HOST);
		if( IAM_WEBSERVICE_HOST==null || (IAM_WEBSERVICE_HOST!=null && IAM_WEBSERVICE_HOST.isEmpty())){
			IAM_WEBSERVICE_HOST="localhost";
			IAM_WEBSERVICE_PORT="9080";
		}
		
		/*java.util.Properties properties = new java.util.Properties();		
		try {
			properties.load(new FileInputStream(WS_CONFIG_FILE));
		} catch (FileNotFoundException e1) {
			System.out.println("The properties file ("+ WS_CONFIG_FILE +"), used for configuring host and port was not found");
			e1.printStackTrace();
		} catch (IOException e1) {
			System.out.println("Error occurred while reading ("+ WS_CONFIG_FILE +")");
			e1.printStackTrace();
		}
		String host = properties.getProperty("host");
		if( host!=null && !host.isEmpty()){
			HOST = host;
			String port = properties.getProperty("port");
			if( port!=null && !port.isEmpty()){
				PORT = port;
			} else {
				isCustomHostAndPortProvided = false;			
			}
		} else {			
			isCustomHostAndPortProvided = false;
		}		*/
	}

	/**
	 * @param serviceName
	 *            Name of the service
	 * @param serviceWSDLFileName
	 *            Name of WSDL file of service
	 * @return URL of the service specified in the input argument
	 */
	private static URL generateServiceURL(String serviceName, String serviceWSDLFileName){
	
		String strURL = "http://" + IAM_WEBSERVICE_HOST + ":" + IAM_WEBSERVICE_PORT + WS_SUFFIX + serviceName + WS_WSDL_LOCATION + serviceWSDLFileName;		
		URL url = null;
		try {
			url = new URL(strURL);			
		} catch (MalformedURLException e) {
			System.out.println("Failed to generate the wsdl resource URL");
			e.printStackTrace();
			System.exit(-1);
		}
		return url;
	}
	
	/**
	 * @return A Session service port on which the service's APIs can be
	 *         invoked.
	 */
	protected static WSSessionService getSessionService() {
		
		WSSessionService_Service service = null;
		URL url = null;		
		String serviceName = "WSSessionService";
		
		if(!isCustomHostAndPortProvided){
			service = new WSSessionService_Service();	
		} else if ( (url = generateServiceURL(serviceName, "WSSessionService.wsdl") ) != null) {
			service = new WSSessionService_Service(url, new QName(namespaceURI, serviceName));			
		} else {			
			return null;
		}
		WSSessionService proxy = service.getWSSessionServicePort();
		return proxy;			
	}

		
	/**
	 * @return A ToDo service port on which the service's APIs can be
	 *         invoked.
	 */
	protected static WSToDoService getToDoService() {
		
		WSToDoServiceService service = null;
		URL url = null;
		String serviceName = "WSToDoServiceService";

		if (!isCustomHostAndPortProvided) {
			service = new WSToDoServiceService();
		} else if ((url = generateServiceURL(serviceName, "WSToDoService.wsdl")) != null) {
			service = new WSToDoServiceService(url, new QName(namespaceURI,
					serviceName));
		} else {
			return null;
		}
		WSToDoService proxy = service.getWSToDoService();
		return proxy;
	}
	
	/**
	 * @return A ExtensionService service port on which the service's APIs can be
	 *         invoked.
	 */
	protected static WSExtensionService getExtensionService() {

		WSExtensionServiceService service = null;
		URL url = null;
		String serviceName = "WSExtensionServiceService";

		if (!isCustomHostAndPortProvided) {
			service = new WSExtensionServiceService();
		} else if ((url = generateServiceURL(serviceName,
				"WSExtensionService.wsdl")) != null) {
			service = new WSExtensionServiceService(url, new QName(
					namespaceURI, serviceName));
		} else {
			return null;
		}
		WSExtensionService proxy = service.getWSExtensionService();
		return proxy;
	}
}
