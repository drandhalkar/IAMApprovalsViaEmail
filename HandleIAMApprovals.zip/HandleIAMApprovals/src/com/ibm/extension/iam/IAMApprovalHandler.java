package com.ibm.extension.iam;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.ibm.itim.dataservices.model.CompoundDN;
import com.ibm.itim.dataservices.model.DistinguishedName;
import com.ibm.itim.dataservices.model.SearchParameters;
import com.ibm.itim.dataservices.model.SearchResults;
import com.ibm.itim.dataservices.model.domain.Account;
import com.ibm.itim.dataservices.model.domain.AccountEntity;
import com.ibm.itim.dataservices.model.domain.AccountSearch;
import com.ibm.itim.dataservices.model.domain.Person;
import com.ibm.itim.dataservices.model.domain.PersonEntity;
import com.ibm.itim.dataservices.model.domain.PersonSearch;
import com.ibm.itim.workflow.model.ActivityResult;
import com.ibm.itim.workflow.model.AssignmentEntity;
import com.ibm.itim.workflow.model.ProcessManager;
import com.ibm.itim.workflow.model.WorkflowProcessEntity;
import com.ibm.itim.ws.client.util.WSSessionExt;
import com.ibm.itim.ws.client.util.xml.XMLBeanReader;
import com.ibm.itim.ws.client.util.xml.XMLBeanWriter;

public class IAMApprovalHandler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static String performAction(WSSessionExt session, String inputXML) {		
		
		System.out.println("invoked performAction");
		String outputMessage = "";
		try {
		// pid="5486855928112593267";
		// activityName="manager";
		// Using XMLBeanReader get the WSPerson object from the XML string

		List<String> inputList = (List<String>) XMLBeanReader.readXMLBean(inputXML, List.class);
		
		//String input = (String) XMLBeanReader.readXMLBean(inputXML, String.class);
		//String inputs[] = input.split("\\|");
		//System.out.println("input length:" + inputs.length);
		String personEmail = inputList.get(0); // (String) XMLBeanReader.readXMLBean(emailXML, String.class);
		String processID = inputList.get(1);// (String) XMLBeanReader.readXMLBean(processIDXML, String.class);
		String activityName = inputList.get(2);// (String) XMLBeanReader.readXMLBean(activityNameXML, String.class);
		String isApproved = inputList.get(3);// (String) XMLBeanReader.readXMLBean(isApprovedXML, String.class);
		String reason = inputList.get(4);// (String) XMLBeanReader.readXMLBean(reasonXML, String.class);
		System.out.println("personEmail pid:" + personEmail);
		System.out.println("processID :" + processID);
		System.out.println("activityName:" + activityName);
		System.out.println("isApproved:" + isApproved);
		System.out.println("reason:" + activityName);

		// Set the search context
		CompoundDN cdn = new CompoundDN();
		DistinguishedName dn = new DistinguishedName("ou=xx, DC=xx,DC=xx");
		cdn.append(dn);
		SearchParameters params = new SearchParameters();
		params.setScope(SearchParameters.SUBTREE_SCOPE);

		String filter = "(mail=" + personEmail + ")";
		System.out.println("Filter used to find uid:" + filter);
		PersonSearch pSearch = new PersonSearch();
		SearchResults results = pSearch.searchByFilter(cdn, filter, params);
		Collection itr = results.toCollection();
		String approverUserID = null;
		System.out.println("person search filter itr:" + itr.size());
		for (Iterator iterator = itr.iterator(); iterator.hasNext();) {
			PersonEntity object = (PersonEntity) iterator.next();
			Person per = ((Person) object.getDirectoryObject());
			approverUserID = per.getAttribute("uid").getValueString();
		}
		if (approverUserID == null) {
			return buildXMLResponse("User is not authorised to perform action on this activity");
		}

		boolean includeISIMAccount = true;
		AccountSearch aSearch = new AccountSearch();
		String aFilter = "(eruid=" + approverUserID + ")";
		SearchResults aSearchResults = aSearch.searchByFilter(cdn, aFilter, params, includeISIMAccount);
		Collection aSeacrhKItr = aSearchResults.toCollection();
		String isimAccountDN = null;
		System.out.println("account search filter itr:" + aSeacrhKItr.size());
		for (Iterator iterator = aSeacrhKItr.iterator(); iterator.hasNext();) {
			AccountEntity object = (AccountEntity) iterator.next();
			Account acct = ((Account) object.getDirectoryObject());

			if (acct.getDistinguishedName().toString().contains("systemUser")) {
				isimAccountDN = acct.getDistinguishedName().toString();
				System.out.println("ISIM account DN:" + isimAccountDN);
				break;
			}
		}
		if (isimAccountDN == null) {
			return buildXMLResponse("User is not authorised to perform action on this activity");
		}

		String assignmentId = "NA";
		ProcessManager pm = new ProcessManager();
		WorkflowProcessEntity process;

		process = pm.getProcess(Long.parseLong(processID));
		System.out.println("getAssignmentID debug2");
		Collection<AssignmentEntity> iamAssignmentEntities = process.getActivity(activityName).getAssignments();
		int aid = 0;
		String potentialOwnerID = null;
		for (Iterator iterator = iamAssignmentEntities.iterator(); iterator.hasNext();) {

			System.out.println("got assignment ids");
			AssignmentEntity assignmentEntity = (AssignmentEntity) iterator.next();
			Collection owners = assignmentEntity.getPotentialOwners();
			System.out.println("owners:" + owners.size());
			for (Iterator iterator1 = owners.iterator(); iterator1.hasNext();) {
				DistinguishedName ownerDN = (DistinguishedName) iterator1.next();
				System.out.println("DN:" + ownerDN);
				PersonSearch search = new PersonSearch();
				PersonEntity personEntity = search.lookup(ownerDN);
				Person person = (Person) personEntity.getDirectoryObject();
				potentialOwnerID = person.getAttribute("uid").getValueString();
				System.out.println("eruid:" + potentialOwnerID);
				if (potentialOwnerID.equalsIgnoreCase(approverUserID)) {
					System.out.println("Approved:" + isApproved);
					if (isApproved.equalsIgnoreCase("false")) {
						assignmentEntity.complete(new DistinguishedName(isimAccountDN),
								new ActivityResult(ActivityResult.REJECTED, reason, null));
					} else {
						assignmentEntity.complete(new DistinguishedName(isimAccountDN),
								new ActivityResult(ActivityResult.APPROVED, reason, null));
					}
					return buildXMLResponse("success");
				}
			}
			System.out.println("invoked getAssignmentID:" + assignmentEntity.getActivity().getId());
			break;
		}
		
		if (aid == 0) {
			return buildXMLResponse("Activity has already been completed!");
		} else if (!potentialOwnerID.equalsIgnoreCase(approverUserID)) {
			return buildXMLResponse("User is not authorised to perform action on this activity.");
		}

		outputMessage=buildXMLResponse(outputMessage);

		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Exception occurred while perfomring action:"+e.getMessage());			
		}
		return outputMessage;
	}

	private static String buildXMLResponse(String message) throws IOException {
		return XMLBeanWriter.writeXMLBean(message);
	}

	/*
	 * public static String doAction(WSSessionExt session, String paramsXML){ long
	 * aid=0; try {
	 * System.out.println("IAMApprovalHandler extension service:doAction...");
	 * ProcessManager pm = new ProcessManager(); WorkflowProcessEntity process;
	 * process = pm.getProcess(Long.parseLong(""));
	 * System.out.println("getAssignmentID debug2"); Collection f =
	 * process.getChildren(); System.out.println("number of childs:" + f.size());
	 * for (Iterator iterator = f.iterator(); iterator.hasNext();) {
	 * WorkflowProcessEntity workflowProcessEntity = (WorkflowProcessEntity)
	 * iterator.next(); System.out.println("workflowProcessEntity id:" +
	 * workflowProcessEntity.getId()); }
	 * 
	 * Collection<AssignmentEntity> iamAssignmentEntities =
	 * process.getActivity("Manager Activity").getAssignments();
	 * 
	 * for (Iterator iterator = iamAssignmentEntities.iterator();
	 * iterator.hasNext();) { System.out.println("got assignment ids");
	 * AssignmentEntity assignmentEntity = (AssignmentEntity) iterator.next();
	 * System.out.println("a id is-" + assignmentEntity.getActivity().getId()); aid
	 * = assignmentEntity.getActivity().getId(); } }catch(Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * return new Long(aid).toString(); }
	 */
	public static String doSomething(String id) {
		System.out.println("doSomething excuted!" + id);
		return "done!";
	}

	/*
	 * public String performAction(String pid,String activityName,String
	 * eruid,boolean isApproved,String reason){ String outputMessage="Success";
	 * //pid="5486855928112593267"; //activityName="manager";
	 * System.out.println("invoked getAssignmentID"); String assignmentId="NA";
	 * ProcessManager pm=new ProcessManager(); WorkflowProcessEntity process; try {
	 * 
	 * System.out.println("getAssignmentID pid:"+pid);
	 * System.out.println("getAssignmentID activityName:"+activityName);
	 * 
	 * process = pm.getProcess(Long.parseLong(pid));
	 * System.out.println("getAssignmentID debug2"); String
	 * userID=getSubjectUserID(subject);
	 * 
	 * Collection<AssignmentEntity> iamAssignmentEntities =
	 * process.getActivity(activityName).getAssignments(); int aid=0; for (Iterator
	 * iterator = iamAssignmentEntities.iterator(); iterator.hasNext();) { aid++;
	 * System.out.println("got assignment ids"); AssignmentEntity assignmentEntity =
	 * (AssignmentEntity) iterator.next(); Collection
	 * owners=assignmentEntity.getPotentialOwners();
	 * System.out.println("owners:"+owners.size()); for (Iterator iterator1 =
	 * owners.iterator(); iterator1.hasNext();) { DistinguishedName
	 * ownerDN=(DistinguishedName)iterator1.next();
	 * System.out.println("DN:"+ownerDN); PersonSearch search = new PersonSearch();
	 * PersonEntity personEntity = search.lookup(ownerDN); Person person = (Person)
	 * personEntity.getDirectoryObject(); String
	 * id=person.getAttribute("uid").getValueString();
	 * System.out.println("eruid:"+id);
	 * System.out.println("logged in user id:"+userID);
	 * if(id.equalsIgnoreCase(userID)){ aid++; String
	 * udn="eruid="+userID+", ou=systemUser, ou=itim, ou=xx, DC=xx,DC=xx";
	 * if(isApproved){ assignmentEntity.complete(new DistinguishedName(udn), new
	 * ActivityResult(ActivityResult.APPROVED,reason,null)); }else{
	 * assignmentEntity.complete(new DistinguishedName(udn), new
	 * ActivityResult(ActivityResult.REJECTED,reason,null)); } } }
	 * System.out.println("invoked getAssignmentID:"+assignmentEntity.getActivity().
	 * getId()); break; } if(aid==0){
	 * outputMessage="Activity has already been completed!"; } if(aid==1){
	 * outputMessage="User is not authorised to action on this activity."; } } catch
	 * (Exception e) { System.out.println("Exception:"+e);
	 * outputMessage=e.getMessage(); e.printStackTrace(); } return outputMessage; }
	 */

}
