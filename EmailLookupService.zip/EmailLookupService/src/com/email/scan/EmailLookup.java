package com.email.scan;

import java.net.URI;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.ibm.ap.IAMApprovalService;

import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.ItemView;

public class EmailLookup {
	
	public static void main(String[] args) {

		try {
			int minutesToMinus=Integer.parseInt("-3600");
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			cal.add(Calendar.MINUTE,minutesToMinus );
			//cal.add(Calendar.HOUR, -30);
			Date newdate = cal.getTime();
			System.out.println("date:"+newdate);
			scanEmails(newdate);
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

	private static String scanEmails(Date date) throws Exception {
		IAMApprovalService apService=new IAMApprovalService();
		ExchangeService service = new ExchangeService();
        ExchangeCredentials credentials = new WebCredentials("xxx@xx.xx", "xxxxx");
        service.setUrl(new URI("https://mail.xxx.xxx/EWS/Exchange.asmx"));
        service.setCredentials(credentials);
        service.setTraceEnabled(true);
        Folder inbox = Folder.bind(service, WellKnownFolderName.Inbox);
        System.out.println("messages: " + inbox.getTotalCount());
        System.out.println("unread count: " +inbox.getUnreadCount());
        System.out.println("startdate:"+new Date());
        ItemView itemview = new ItemView(1);        
		FindItemsResults<Item> findResults = service.findItems(inbox.getId(), itemview);
		System.out.println("enddate:"+new Date());
		for(Item emailItem : findResults){
			if(emailItem.getDateTimeCreated().compareTo(date)>=0) {
				emailItem.load();
				String senderEmail = ((EmailMessage) emailItem).getFrom().getAddress();//getSender().getAddress();//getFrom().getAddress();				
				System.out.println("email DateTime received:"+emailItem.getDateTimeCreated());
				String emailSubject=emailItem.getSubject();
				System.out.println("email by:"+senderEmail);
				System.out.println("emailSubject : "+emailSubject);
				//Consider email subject has details of request Approved|1223234432423423|ManagerWithNoEscalation
				String inputArr[]=emailSubject.split("\\|");
				List<String> inputlist=new ArrayList<String>();
				System.out.println("inputArr.length:"+inputArr.length);
				if(inputArr.length>2) {					
					List<String> inputList=new ArrayList<String>();
					inputlist.add(senderEmail);
					inputlist.add(inputArr[0]);
					inputlist.add(inputArr[1]);				
					inputlist.add(inputArr[2]);
					System.out.println("inputList lng:"+inputlist.size());
					String output=apService.doAction(inputList);
					System.out.println("doAction lng:"+output);
				}
			}else {
				break;
			}
		}   
		return "";
		
	}
}
